document.addEventListener('DOMContentLoaded', function() {
    // Default page and per_page values
    let currentPage = 1;
    let perPage = 10;

    // Function to fetch CVE data based on filters, page, and per_page
    function fetchCVEs() {
        const filterYear = document.getElementById('filterYear').value;
        const url = `/cves/list?page=${currentPage}&per_page=${perPage}&year=${filterYear}`;
        fetch(url)
            .then(response => response.json())
            .then(data => {
                const cveTableBody = document.getElementById('cveTableBody');
                cveTableBody.innerHTML = ''; // Clear previous rows

                data.cves.forEach(cve => {
                    const row = cveTableBody.insertRow();
                    row.insertCell(0).textContent = cve['CVE ID'];
                    row.insertCell(1).textContent = cve['Description'];
                    row.insertCell(2).textContent = cve['Base Score'];
                    row.insertCell(3).textContent = cve['Last Modified'];
                });

                document.getElementById('currentPage').textContent = `Page ${currentPage}`;
            })
            .catch(error => console.error('Error fetching CVEs:', error));
    }

    // Event listener for perPage select change
    document.getElementById('perPage').addEventListener('change', function() {
        perPage = parseInt(this.value);
        currentPage = 1; // Reset to first page
        fetchCVEs();
    });

    // Event listener for pagination buttons
    document.getElementById('prevPage').addEventListener('click', function() {
        if (currentPage > 1) {
            currentPage--;
            fetchCVEs();
        }
    });

    document.getElementById('nextPage').addEventListener('click', function() {
        currentPage++;
        fetchCVEs();
    });

    // Initial fetch on page load
    fetchCVEs();
});

