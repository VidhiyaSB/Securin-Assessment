from flask import Flask, jsonify, request
from flask_sqlalchemy import SQLAlchemy
import requests

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///../instance/cve_database.db'
db = SQLAlchemy(app)

class CVE(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    cve_id = db.Column(db.String(50), unique=True, nullable=False)
    description = db.Column(db.Text, nullable=False)
    base_score = db.Column(db.Float, nullable=False)
    last_modified = db.Column(db.String(50), nullable=False)

@app.route('/cves/list', methods=['GET'])
def get_cves():
    page = int(request.args.get('page', 1))
    per_page = int(request.args.get('per_page', 10))
    cves = CVE.query.paginate(page=page, per_page=per_page, error_out=False)
    cve_list = [{'CVE ID': cve.cve_id, 'Description': cve.description, 'Base Score': cve.base_score, 'Last Modified': cve.last_modified} for cve in cves.items]
    return jsonify({'cves': cve_list, 'total_records': cves.total})


@app.route('/fetch-cves', methods=['POST'])
def fetch_cves():
    page = 1
    while True:
        response = requests.get(f'https://services.nvd.nist.gov/rest/json/cves/2.0?startIndex={page}&resultsPerPage=1000')
        if response.status_code == 200:
            data = response.json()
            items = data.get('result', {}).get('CVE_Items', [])
            if not items:
                break
            for item in items:
                cve_data = item.get('cve', {})
                cve_id = cve_data.get('CVE_data_meta', {}).get('ID', '')
                description = cve_data.get('description', {}).get('description_data', [])[0].get('value', '')
                base_score = item.get('impact', {}).get('baseMetricV2', {}).get('cvssV2', {}).get('baseScore', 0)
                last_modified = item.get('lastModifiedDate', '')
                cve = CVE(cve_id=cve_id, description=description, base_score=base_score, last_modified=last_modified)
                db.session.add(cve)
            db.session.commit()
            page += 1
        else:
            return jsonify({'error': 'Failed to fetch CVE data'}), 500
    return jsonify({'message': 'CVE data fetched successfully'})

if __name__ == '__main__':
    app.run(debug=True)
