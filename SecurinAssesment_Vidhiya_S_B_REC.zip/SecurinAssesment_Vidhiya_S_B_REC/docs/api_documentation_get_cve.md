# API Documentation: Filter CVEs

This document provides details about the API endpoints available for filtering Common Vulnerabilities and Exposures (CVEs).

## Base URL

The base URL for accessing the API endpoints is `http://localhost:5000`.

## Endpoints

### GET /cves/list

#### Description

This endpoint retrieves a list of CVEs based on specified filters.

#### Parameters

- `page` (optional): Specifies the page number for pagination. Default is 1.
- `per_page` (optional): Specifies the number of results per page. Default is 10.

#### Response

The response contains a JSON object with the following structure:

```json
{
  "cves": [
    {
      "CVE ID": "CVE-2022-1234",
      "Description": "Description of the vulnerability",
      "Base Score": 7.5,
      "Last Modified": "2022-05-01"
    },
    {
      "CVE ID": "CVE-2022-5678",
      "Description": "Description of another vulnerability",
      "Base Score": 8.0,
      "Last Modified": "2022-04-15"
    },
    ...
  ],
  "total_records": 100
}
POST /fetch-cves
Description
This endpoint triggers the fetching of CVE data from the NIST API and stores it in the system's database.

Parameters
None required.

Response
Status Code: 200 OK
Body: { "message": "CVE data fetched successfully" }