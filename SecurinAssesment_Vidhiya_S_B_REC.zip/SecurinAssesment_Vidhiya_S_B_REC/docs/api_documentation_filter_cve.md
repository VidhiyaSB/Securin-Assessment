This document outlines the API endpoints and parameters available for filtering Common Vulnerabilities and Exposures (CVEs) in the system.

Base URL
The base URL for accessing the API endpoints is http://localhost:5000.

Endpoints
GET /cves/list
Description
This endpoint retrieves a list of CVEs based on specified filters.

Parameters
page: (Optional) Specifies the page number for pagination. Default is 1.
per_page: (Optional) Specifies the number of results per page. Default is 10.
Response
The API response contains a JSON object with the following structure:

json
Copy code
{
  "cves": [
    {
      "CVE ID": "CVE-2022-1234",
      "Description": "Description of the vulnerability",
      "Base Score": 7.5,
      "Last Modified": "2022-05-01"
    },
    {
      "CVE ID": "CVE-2022-5678",
      "Description": "Description of another vulnerability",
      "Base Score": 8.0,
      "Last Modified": "2022-04-15"
    },
    ...
  ],
  "total_records": 100
}
POST /fetch-cves
Description
This endpoint triggers the fetching of CVE data from the NIST API and stores it in the system's database.

Parameters
None required.

Response
Status Code: 200 OK
Body: { "message": "CVE data fetched successfully" }