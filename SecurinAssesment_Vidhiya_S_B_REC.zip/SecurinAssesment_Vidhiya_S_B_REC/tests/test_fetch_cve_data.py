import unittest
from fetch_cve_data import fetch_cve_data

class TestFetchCVEData(unittest.TestCase):
    def test_fetch_cve_data(self):
        cve_data = fetch_cve_data(0, 10)  # Example parameters
        self.assertIsNotNone(cve_data)
        self.assertIsInstance(cve_data, list)

if __name__ == '__main__':
    unittest.main()
